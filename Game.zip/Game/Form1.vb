﻿Imports System.Text
Imports System.IO
Imports System.Net

Public Class Form1

    Private Sub btn_SelectFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SelectFile.Click
        FolderBrowserDialog1.Description = "请指定文件夹。"
        FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.Desktop
        FolderBrowserDialog1.SelectedPath = "C:\\"
        FolderBrowserDialog1.ShowNewFolderButton = True
        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txt_AppPath.Text = FolderBrowserDialog1.SelectedPath + "\\bin\\exefile.exe"
        End If

    End Sub

    Private Sub btn_login_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_login.Click
        Dim httpWebResponse As Net.HttpWebResponse
        Dim requestUriString As String
        Dim cookieContainer As Net.CookieContainer
        Dim str As String
        Dim text As String
        Dim a As String
        Dim a2 As String
        text = txt_AppPath.Text.Trim()
        a = txt_username.Text.Trim()
        a2 = txt_password.Text.Trim()
        Try
            If a = "" Or a2 = "" Or text = "" Then
                MessageBox.Show("游戏路径和用户名密码不能为空！")
                Return
            End If

            If Dir(text) = "" Then
                MessageBox.Show("游戏路径错误！\r\n请将登录器放置于EVE安装目录，或人工设置游戏路径。")
                Return
            End If

            Dim text2 As String
            text2 = "username=" + txt_username.Text.Trim() + "&password=" + txt_password.Text.Trim()
            Dim s As String
            s = a2
            Dim requestUriString2 As String
            requestUriString2 = "https://auth.eve-online.com.cn/Account/LogOn?ReturnUrl=%2foauth%2fauthorize%3fclient_id%3deveclient%26scope%3deveClientLogin%26response_type%3dtoken%26redirect_uri%3dhttps%253A%252F%252Fauth.eve-online.com.cn%252Flauncher%253Fclient_id%253Deveclient%26lang%3d"
            Dim httpWebRequest As Net.HttpWebRequest
            Dim request As Net.WebRequest = Net.WebRequest.Create(requestUriString2)
            httpWebRequest = request
            httpWebRequest.Method = "POST"
            httpWebRequest.ContentType = "application/x-www-form-urlencoded"
            Dim bytes() As Byte = Encoding.GetEncoding("gbk").GetBytes(s)
            httpWebRequest.ContentLength = bytes.Length
            httpWebRequest.Referer = requestUriString2
            httpWebRequest.AllowAutoRedirect = False
            httpWebRequest.CookieContainer = cookieContainer
            httpWebRequest.KeepAlive = True
            Dim requestStream As Stream = httpWebRequest.GetRequestStream()
            requestStream.Write(bytes, 0, bytes.Length)
            requestStream.Close()
            httpWebResponse = httpWebRequest.GetResponse()
            httpWebResponse.Cookies = httpWebRequest.CookieContainer.GetCookies(httpWebRequest.RequestUri)
            Dim arg_183_0 As CookieCollection = httpWebResponse.Cookies
            Dim cookieHeader As String = httpWebRequest.CookieContainer.GetCookieHeader(httpWebRequest.RequestUri)
            str = cookieHeader
            httpWebResponse.Close()
        Catch ex As Exception
            Trace.Write("1st Error!")
            MessageBox.Show("用户登录失败，请检查帐号密码是否正确。")
            Return
        End Try
        Try
            Dim text3 As String = httpWebResponse.Headers("location")
            If text3 = "" Then
                MessageBox.Show("用户登录失败，请检查帐号密码是否正确。")
            Else
                requestUriString = "https://auth.eve-online.com.cn" + text3
                Dim httpWebRequest As HttpWebRequest = WebRequest.Create(requestUriString)
                httpWebRequest.Method = "GET"
                httpWebRequest.KeepAlive = True
                httpWebRequest.Headers.Add("Cookie:" + str)
                httpWebRequest.CookieContainer = cookieContainer
                httpWebRequest.AllowAutoRedirect = True
                httpWebRequest.AllowAutoRedirect = False
                httpWebResponse = httpWebRequest.GetResponse()
                str = httpWebRequest.CookieContainer.GetCookieHeader(httpWebRequest.RequestUri)
                Dim streamReader As StreamReader = New StreamReader(httpWebResponse.GetResponseStream(), System.Text.Encoding.GetEncoding("gbk"))
                streamReader.ReadToEnd()
                httpWebRequest.Abort()
                streamReader.Close()
                httpWebResponse.Close()
                Dim text4 As String = httpWebResponse.Headers.Get("location")
                Dim array() As String = Split(text4, "=")
                Dim array2() As String = Split(array(2), "&")
                Dim text5 As String = array2(0)
                If array(0) <> "eveclient#access_token" Then
                    MessageBox.Show("用户登录失败，请检查帐号密码是否正确。")
                Else
                    Trace.Write(text5)
                    Dim arguments As String = "/noconsole /ssoToken=" + text5
                    Dim myProcess As Process = New Process()
                    myProcess.StartInfo.FileName = text
                    myProcess.StartInfo.Arguments = arguments
                    myProcess.Start()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim startupPath As String
        startupPath = Application.StartupPath
        txt_AppPath.Text = startupPath + "\\bin\\exefile.exe"
    End Sub
End Class
